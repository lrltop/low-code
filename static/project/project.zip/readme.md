# 项目静态文件打包为zip放在此目录，方便生成代码时候解压读取，并和动态文件生成的目标文件一起打包

project.zip

project
-- store
---- .......
-- libs
---- .......
-- common
---- .......
-- index.html