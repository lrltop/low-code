<template>
  <view class="phone-content">
    <view class="margin-0">
    </view>
  </view>
</template>
<script>
  export default {
      name: "index",
      data() {
          return {}
      },
      // 组件
      components: {},
  }
</script>
<style scoped>
  .phone-content {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
  }
</style>
